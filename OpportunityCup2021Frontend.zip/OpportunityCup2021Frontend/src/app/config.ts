export class Config {

  // URL адрес backend сервера (должна быть включена политика CORS, если сервер сторонний)
  static URL = `${location.protocol}//${location.hostname}:8080`;

}
